/**
 ** Isaac Genome Alignment Software
 ** Copyright (c) 2010-2014 Illumina, Inc.
 ** All rights reserved.
 **
 ** This software is provided under the terms and conditions of the
 ** GNU GENERAL PUBLIC LICENSE Version 3
 **
 ** You should have received a copy of the GNU GENERAL PUBLIC LICENSE Version 3
 ** along with this program. If not, see
 ** <https://github.com/illumina/licenses/>.
 **
 ** \file Read.cpp
 **
 ** Component containing the data associated to a cluster: sequence and quality
 ** strings for all the reads in the cluster.
 **
 ** \author Come Raczy
 **/

#include <cassert>
#include <boost/foreach.hpp>

#include "oligo/Nucleotides.hh"
#include "alignment/Read.hh"

namespace isaac
{
namespace alignment
{

void Read::decodeBcl(
    BclClusters::const_iterator bclBegin,
    BclClusters::const_iterator bclEnd,
    const unsigned index)
{
    ISAAC_ASSERT_MSG(index_ == index, "Unexpected initialization of one read with another");
    ISAAC_ASSERT_MSG(bclEnd > bclBegin, "Invalid iterator range");
    ISAAC_ASSERT_MSG(forwardSequence_.capacity() >= std::size_t(std::distance(bclBegin, bclEnd)), "Buffers expected to be preallocated");
    ISAAC_ASSERT_MSG(reverseSequence_.capacity() >= std::size_t(std::distance(bclBegin, bclEnd)), "Buffers expected to be preallocated");
    ISAAC_ASSERT_MSG(forwardQuality_.capacity() >= std::size_t(std::distance(bclBegin, bclEnd)), "Buffers expected to be preallocated");
    ISAAC_ASSERT_MSG(reverseQuality_.capacity() >= std::size_t(std::distance(bclBegin, bclEnd)), "Buffers expected to be preallocated");
//    sequence_.reserve(readLength);
    forwardSequence_.clear();
    reverseSequence_.clear();
//    quality_.reserve(readLength);
    forwardQuality_.clear();
    reverseQuality_.clear();
    /*beginCyclesMasked_ = 0L;*/
    endCyclesMasked_ = 0L;

    for (BclClusters::const_iterator bcl = bclBegin; bclEnd > bcl; ++bcl)
    {

        if (!oligo::isBclN(*bcl))
        {
            forwardSequence_.push_back(oligo::getBase((*bcl) & 3, true));
            reverseSequence_.push_back(oligo::getBase((~(*bcl)) & 3, true));
            forwardQuality_.push_back(oligo::getQuality(*bcl));
            reverseQuality_.push_back(oligo::getQuality(*bcl));
        }
        else
        {
            forwardSequence_.push_back(oligo::SEQUENCE_OLIGO_N); // so that it mismatches with oligo::REFERENCE_OLIGO_N in the reference
            reverseSequence_.push_back(oligo::SEQUENCE_OLIGO_N); // so that it mismatches with oligo::REFERENCE_OLIGO_N in the reference
            forwardQuality_.push_back(2);
            reverseQuality_.push_back(2);
        }
    }
    std::reverse(reverseSequence_.begin(), reverseSequence_.end());
    std::reverse(reverseQuality_.begin(), reverseQuality_.end());
}

std::ostream &operator<<(std::ostream &os, const Read &read)
{
    os << "Read:" << std::endl;
    os << "    "; BOOST_FOREACH(const char c, read.getForwardSequence()) {os << c;} os << std::endl;
    os << "    "; BOOST_FOREACH(const char c, read.getForwardQuality()) {os << c;} os << std::endl;
    os << "    "; BOOST_FOREACH(const char c, read.getReverseSequence()) {os << c;} os << std::endl;
    os << "    "; BOOST_FOREACH(const char c, read.getReverseQuality()) {os << c;} os << std::endl;
    return os;
}

} // namespace alignment
} // namespace isaac
